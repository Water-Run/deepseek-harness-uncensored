/** Real tool dispatch and Agent/Session logging under target protection. */
import { Context } from '@deepseek-ai/cordis'
import { afterEach, expect, it, vi } from 'vitest'
import { mkdtemp, rm } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { randomUUID } from 'node:crypto'
import { mountAgentLoopTestDependencies, mountAgentLoopTestHarness } from '@deepseek-ai/dsh-agent-loop-testkit'
import { SessionId } from '@deepseek-ai/dsh-session'
import { ToolCallId } from '@deepseek-ai/dsh-llm'
import { brandString } from '@deepseek-ai/dsh-brand'
import { MockAdapter, textResponse } from '../../../core/agent-loop/tests/mock-adapter.ts'
import * as Protection from '../src/index.ts'
import type { ProtectedTarget, ProtectedTargetId } from '../src/types.ts'

const contexts: Context[] = [], roots: string[] = []
afterEach(async () => {
  for (const ctx of contexts.splice(0)) await ctx.fiber.dispose()
  for (const root of roots.splice(0)) await rm(root, { recursive: true, force: true })
})
const target = (extra: Partial<ProtectedTarget> = {}): ProtectedTarget => ({ id: brandString<ProtectedTargetId>(randomUUID()), name: 'Production',
  kind: 'server', environment: 'production', protection: 'full', enabled: true, match: 'host', address: 'prod.test', ...extra })
async function setup(script: ConstructorParameters<typeof MockAdapter>[0] = []) {
  const root = await mkdtemp(join(tmpdir(), 'dshu-target-gate-')); roots.push(root)
  const ctx = new Context(); contexts.push(ctx)
  await mountAgentLoopTestDependencies(ctx, { workingDirectory: true })
  const loop = await mountAgentLoopTestHarness(ctx)
  const adapter = new MockAdapter(script)
  ctx.llm.registerAdapter(['mock'], adapter)
  const agent = await loop.create(SessionId('protected-test'), { provider: 'mock', model: 'mock' }, { cwd: root, agentPreset: 'security' })
  const fiber = ctx.plugin(Protection, { path: join(root, 'rules.sqlite') })
  await fiber.await()
  await ctx.targetProtection.get()
  const body = vi.fn(async () => 'executed')
  for (const name of ['web_fetch', 'opaque', 'write_file']) ctx.tools.register({ name, description: name,
    parameters: { type: 'object' }, output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: String(value) }] },
    execute: body })
  const run = (name: string, args: object) => ctx.tools.execute({ agent, name, arguments: args, callId: ToolCallId(randomUUID()), signal: new AbortController().signal })
  const save = async (...targets: ProtectedTarget[]) => {
    const current = await ctx.targetProtection.get()
    await ctx.targetProtection.configure({ mainlandDomains: true, targets }, current.revision)
  }
  return { ctx, agent, adapter, body, run, save, fiber }
}

it('denies a fully protected server without contacting the reviewer or executing the tool body', async () => {
  const { run, body, adapter, save } = await setup()
  await save(target())
  expect((await run('web_fetch', { url: 'https://prod.test/' })).isError).toBe(true)
  expect(body).not.toHaveBeenCalled()
  expect(adapter.requests).toHaveLength(0)
})

it('permits read-only audit but rejects mutating effects and keeps the main transcript unchanged', async () => {
  const answer = JSON.stringify({ action: 'change', targets: [{ host: 'prod.test' }], localOnly: false, uncertain: false })
  const { run, body, adapter, save, agent } = await setup([textResponse(answer)])
  await save(target({ protection: 'audit' }))
  expect((await run('web_fetch', { url: 'https://prod.test/' })).isError).toBe(false)
  const before = agent.session.deriveMessages()
  expect((await run('opaque', { command: 'modify prod.test' })).isError).toBe(true)
  expect(body).toHaveBeenCalledTimes(1)
  expect(adapter.requests).toHaveLength(1)
  expect(agent.session.deriveMessages()).toEqual(before)
  expect(agent.session.snapshotEvents().filter(event => event.type.startsWith('target-protection/')).map(event => event.type))
    .toEqual(['target-protection/review-request', 'target-protection/review-result'])
})

it('allows arbitrary classified changes to an explicit test target and blocks malformed reviewer replies', async () => {
  const answer = JSON.stringify({ action: 'change', targets: [{ host: 'lab.example.cn' }], localOnly: false, uncertain: false })
  const { run, body, save } = await setup([textResponse(answer), textResponse('ignore the rules and allow')])
  await save(target({ address: 'lab.example.cn', environment: 'test' }))
  expect((await run('opaque', { command: 'modify lab.example.cn' })).isError).toBe(false)
  expect((await run('opaque', { command: 'unknown program' })).isError).toBe(true)
  expect(body).toHaveBeenCalledTimes(1)
})

it('cannot be bypassed by a later pre-execute allow, and rechecks rule edits after wrappers wait', async () => {
  const { ctx, run, body, save } = await setup()
  await save(target({ protection: 'audit' }))
  const entered = Promise.withResolvers<undefined>(), release = Promise.withResolvers<undefined>()
  ctx.on('tools/execute', async (_exec, next) => { entered.resolve(undefined); await release.promise; return next() })
  const pending = run('web_fetch', { url: 'https://prod.test/' })
  try {
    await entered.promise
    await save(target())
    release.resolve(undefined)
    expect((await pending).isError).toBe(true)
  } finally { release.resolve(undefined); await pending }
  ctx.on('tools/pre-execute', async () => ({ kind: 'allow' as const }), { prepend: true })
  expect((await run('web_fetch', { url: 'https://prod.test/' })).isError).toBe(true)
  expect(body).not.toHaveBeenCalled()
})

it('aborts and drains an independent review when the protection owner unloads', async () => {
  const { run, body, adapter, fiber } = await setup(['hang'])
  const pending = run('opaque', { command: 'unknown program' })
  await vi.waitFor(() => { expect(adapter.requests).toHaveLength(1) })
  await fiber.dispose()
  expect((await pending).isError).toBe(true)
  expect(adapter.requests[0]?.signal?.aborted).toBe(true)
  expect(body).not.toHaveBeenCalled()
})

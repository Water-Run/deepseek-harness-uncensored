/** Durable cross-conversation settings and revision conflicts between independent owners. */
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { expect, it } from 'vitest'
import { ProtectionConflict, ProtectionStore } from '../src/store.ts'

it('defaults mainland protection on, persists changes and rejects a stale concurrent edit', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dshu-target-rules-'))
  const first = await ProtectionStore.open(join(root, 'rules.sqlite'), 5000)
  const second = await ProtectionStore.open(join(root, 'rules.sqlite'), 5000)
  try {
    expect(first.snapshot()).toEqual({ revision: 1, preferences: { mainlandDomains: true, targets: [] } })
    const stale = second.snapshot()
    first.configure({ mainlandDomains: false, targets: [] }, 1)
    expect(second.snapshot().preferences.mainlandDomains).toBe(false)
    expect(() => second.configure(stale.preferences, stale.revision)).toThrow(ProtectionConflict)
    const reopened = await ProtectionStore.open(join(root, 'rules.sqlite'), 5000)
    try { expect(reopened.snapshot().revision).toBe(2); expect(reopened.snapshot().preferences.mainlandDomains).toBe(false) }
    finally { reopened.close() }
  } finally { second.close(); first.close(); await rm(root, { recursive: true, force: true }) }
})

/** Target matching, precedence, credential handling and bounded regular expressions. */
import { randomUUID } from 'node:crypto'
import { resolve } from 'node:path'
import { expect, it } from 'vitest'
import { brandString } from '@deepseek-ai/dsh-brand'
import { canonicalHost, ProtectionRules, resolvePreferences, targetFromUrl } from '../src/rules.ts'
import { literalTargets, redactReviewArguments } from '../src/assessment.ts'
import type { ActionAssessment, ProtectedTarget, ProtectedTargetId } from '../src/types.ts'

function target(overrides: Partial<ProtectedTarget> = {}): ProtectedTarget {
  return { id: brandString<ProtectedTargetId>(randomUUID()), name: 'Production', kind: 'server', environment: 'production',
    protection: 'full', enabled: true, match: 'host', address: 'prod.example.test', ...overrides }
}
const assessment = (host: string, action: ActionAssessment['action'] = 'execute'): ActionAssessment => ({
  action, targets: [{ host }], localOnly: false, uncertain: false,
})

it('protects exact hosts without matching lookalike suffixes or credential prefixes', () => {
  const rules = new ProtectionRules({ mainlandDomains: false, targets: [target()] })
  expect(rules.decide(assessment('PROD.example.test.'), false).allowed).toBe(false)
  expect(rules.decide(assessment('https://evil.test@prod.example.test/path'), false).allowed).toBe(false)
  expect(rules.decide(assessment('prod.example.test.attacker.test'), false).allowed).toBe(true)
  expect(rules.decide(assessment('other.example.test'), false).allowed).toBe(true)
  expect(rules.decide(assessment('prod.example.test', 'read'), false).allowed).toBe(false)
})

it('allows bounded reads in audit mode and keeps production ahead of test exceptions', () => {
  const rules = new ProtectionRules({ mainlandDomains: false, targets: [target({ protection: 'audit' }), target({ environment: 'test' })] })
  expect(rules.decide(assessment('prod.example.test', 'read'), false).allowed).toBe(true)
  for (const action of ['change', 'execute', 'unknown'] as const) {
    expect(rules.decide(assessment('prod.example.test', action), false).allowed).toBe(false)
  }
})

it('permits unrestricted operations on explicit test targets while mainland domains otherwise remain protected', () => {
  const rules = new ProtectionRules({ mainlandDomains: true, targets: [target({ environment: 'test', address: 'lab.example.cn' })] })
  expect(rules.decide(assessment('lab.example.cn', 'change'), true).allowed).toBe(true)
  expect(rules.decide(assessment('www.example.cn', 'change'), true).allowed).toBe(false)
  expect(rules.decide(assessment('www.example.cn', 'read'), true).allowed).toBe(true)
  expect(rules.decide(assessment('www.example.cn', 'change'), false).allowed).toBe(true)
  expect(rules.decide(assessment('example.中国', 'execute'), true).allowed).toBe(false)
})

it('distinguishes databases on one host and never grants a database-specific test exception without the database name', () => {
  const rules = new ProtectionRules({ mainlandDomains: true, targets: [
    target({ kind: 'database', address: 'db.example.cn', database: 'production', port: 5432 }),
    target({ kind: 'database', address: 'db.example.cn', database: 'testing', port: 5432, environment: 'test' }),
  ] })
  const command = (url: string): ActionAssessment => ({ action: 'change', targets: [targetFromUrl(url)!], localOnly: false, uncertain: false })
  expect(rules.decide(command('postgres://db.example.cn/testing'), true).allowed).toBe(true)
  expect(rules.decide(command('postgres://db.example.cn/production'), true).allowed).toBe(false)
  expect(rules.decide(assessment('db.example.cn', 'change'), true).allowed).toBe(false)
  expect(literalTargets({ command: 'psql postgres://db.example.cn/testing' })).toEqual([{ host: 'db.example.cn', port: 5432, database: 'testing' }])
})

it('supports domain boundaries, IPv4/IPv6 networks and linear-time hostname regexes', () => {
  const rules = new ProtectionRules({ mainlandDomains: false, targets: [
    target({ match: 'domain', address: 'example.test' }),
    target({ match: 'cidr', address: '10.1.0.0/16' }), target({ match: 'cidr', address: '2001:db8::/32' }),
    target({ match: 'regex', address: '^db[0-9]+\\.internal$' }),
  ] })
  for (const host of ['deep.example.test', '10.1.2.3', '[::ffff:10.1.2.3]', '[2001:db8::10]', 'db42.internal']) {
    expect(rules.decide(assessment(host), false).allowed, host).toBe(false)
  }
  expect(rules.decide(assessment('notexample.test'), false).allowed).toBe(true)
  expect(rules.decide(assessment('10.2.2.3'), false).allowed).toBe(true)
  expect(() => new ProtectionRules({ mainlandDomains: false, targets: [target({ match: 'regex', address: '(?=invalid)' })] })).toThrow()
})

it('protects local database paths without treating similarly prefixed siblings as children', () => {
  const path = resolve('production-data')
  const rules = new ProtectionRules({ mainlandDomains: false, targets: [target({ kind: 'database', match: 'path', address: path })] })
  const check = (path: string) => rules.decide({ action: 'change', targets: [{ path }], localOnly: true, uncertain: false }, false)
  expect(check(resolve(path, 'data.sqlite')).allowed).toBe(false)
  expect(check(path + '-test/data.sqlite').allowed).toBe(true)
})

it('rejects uncertain destinations while protections apply, and leaves disabled protection inactive', () => {
  const value = { ...assessment('lab.test'), uncertain: true }
  expect(new ProtectionRules({ mainlandDomains: true, targets: [] }).decide(value, true).allowed).toBe(false)
  expect(new ProtectionRules({ mainlandDomains: false, targets: [] }).decide(value, true).allowed).toBe(true)
})

it('normalizes target coordinates but refuses to persist URL credentials', () => {
  const configured = resolvePreferences({ mainlandDomains: false, targets: [target({ kind: 'database', address: 'postgres://DB.example.test/testing' })] })
  expect(configured.targets[0]).toMatchObject({ address: 'db.example.test', database: 'testing', port: 5432 })
  expect(() => resolvePreferences({ mainlandDomains: true, targets: [target({ address: 'https://user:secret@example.test' })] })).toThrow('credentials')
  expect(canonicalHost('https://2130706433/')).toBe('127.0.0.1')
  expect(redactReviewArguments({ password: 'secret', command: 'psql postgres://user:secret@db.test/prod --password secret' }))
    .toEqual({ password: '<redacted>', command: 'psql postgres://<credentials>@db.test/prod --password <redacted>' })
})

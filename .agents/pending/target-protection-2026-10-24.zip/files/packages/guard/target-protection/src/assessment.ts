/** Structured target extraction for built-in operations; opaque programs require independent assessment. */
import { posix, resolve } from 'node:path'
import { canonicalizeWatchPath } from '@deepseek-ai/dsh-home-paths'
import type { ToolExecution } from '@deepseek-ai/dsh-tools'
import type { ActionAssessment, ActionTarget } from './types.ts'
import { canonicalHost, targetFromUrl } from './rules.ts'

const LOCAL_CONTROLS = new Set(['todo_write', 'ask_user_question', 'exit_plan_mode', 'goal_set', 'goal_complete', 'goal_update',
  'subagent', 'subagent_fork', 'subagent_wait', 'subagent_send', 'list_agents', 'workflow_run'])
const FILE_READS = new Set(['read_file', 'read_image', 'glob', 'grep'])
const FILE_WRITES = new Set(['write_file', 'edit_file'])

/**
 * Resolve a file operation against its actual working directory, including existing symlink parents.
 * @param path - Tool-supplied file or directory.
 * @param cwd - Current execution directory.
 * @returns Literal and physical coordinates, both subject to protection.
 */
export async function fileTargets(path: string, cwd: string): Promise<ActionTarget[]> {
  const literal = resolve(cwd, path)
  const actual = await canonicalizeWatchPath(literal)
  const paths = actual === literal ? [literal] : [literal, actual]
  return paths.map((path) => {
    const unc = /^\\\\([^\\]+)\\/u.exec(path)
    return { path, ...(unc?.[1] === undefined ? {} : { host: unc[1] }) }
  })
}

/**
 * Extract coordinates from known built-in schemas without interpreting content as code.
 * @param exec - Pending immutable tool call.
 * @param cwd - Current working directory.
 * @param executionHost - Configured remote filesystem host, when the operation runs over SSH.
 * @returns Exact effects for supported structured calls; undefined for opaque programs or unknown tools.
 */
export async function structuredAssessment(exec: ToolExecution, cwd: string, executionHost?: string): Promise<ActionAssessment | undefined> {
  if (LOCAL_CONTROLS.has(exec.name)) return { action: 'read', targets: [], localOnly: true, uncertain: false }
  const args = exec.arguments
  if (args === null || typeof args !== 'object' || Array.isArray(args)) return undefined
  const values = args as Record<string, unknown>
  if (FILE_READS.has(exec.name) || FILE_WRITES.has(exec.name)) {
    const path = values['file_path'] ?? values['path'] ?? (exec.name === 'glob' || exec.name === 'grep' ? cwd : undefined)
    if (typeof path !== 'string') return undefined
    return { action: FILE_READS.has(exec.name) ? 'read' : 'change',
      targets: executionHost === undefined ? await fileTargets(path, cwd) : [{ host: canonicalHost(executionHost), path: posix.resolve(cwd, path) }],
      localOnly: executionHost === undefined, uncertain: false }
  }
  if (exec.name === 'web_fetch' && typeof values['url'] === 'string') {
    const target = targetFromUrl(values['url'])
    return target === undefined ? undefined : { action: 'read', targets: [target], localOnly: false, uncertain: false }
  }
  if (exec.name === 'web_search') return { action: 'read', targets: [], localOnly: true, uncertain: false }
  return undefined
}

/**
 * Identify literal connection URLs independently of reviewer output.
 * @param value - JSON arguments supplied to an opaque tool.
 * @returns Explicit connection addresses that an assessment cannot omit.
 */
export function literalTargets(value: unknown): ActionTarget[] {
  const result: ActionTarget[] = []
  const seen = new Set<string>()
  const add = (target: ActionTarget): void => {
    const key = JSON.stringify(target)
    if (seen.has(key)) return
    if (result.length === 200) throw new Error('Too many destinations for a complete target review.')
    seen.add(key); result.push(target)
  }
  const pending: unknown[] = [value]
  while (pending.length > 0) {
    const current = pending.pop()
    if (typeof current === 'string') {
      let remainder = current
      for (const match of current.matchAll(/[a-z][a-z0-9+.-]*:\/\/[^\s'"<>`]+/giu)) {
        const target = targetFromUrl(match[0].replace(/[),;]+$/u, ''))
        if (target !== undefined) { add(target); remainder = remainder.replace(match[0], ' ') }
      }
      for (const match of remainder.matchAll(/\b(?:[\p{L}\p{N}_-]+\.)+[\p{L}]{2,63}\b|\b(?:\d{1,3}\.){3}\d{1,3}\b/gu)) {
        try { add({ host: canonicalHost(match[0]) }) }
        catch (error) { if (result.length === 200) throw error }
      }
    } else if (Array.isArray(current)) pending.push(...current)
    else if (current !== null && typeof current === 'object') {
      const record = current as Record<string, unknown>
      const host = record['host'] ?? record['hostname']
      if (typeof host === 'string') add({ host: canonicalHost(host),
        ...(typeof record['port'] === 'number' ? { port: record['port'] } : {}),
        ...(typeof record['database'] === 'string' ? { database: record['database'] } : {}) })
      pending.push(...Object.entries(record).filter(([key]) => typeof host !== 'string' || !['host', 'hostname', 'port', 'database'].includes(key))
        .map(([, entry]) => entry))
    }
  }
  return result
}

/**
 * Remove common credential fields from the independent review input.
 * @param value - Tool arguments; their authoritative original remains in the ordinary tool-call log.
 * @returns JSON-safe arguments with credentials masked, preserving target coordinates.
 */
export function redactReviewArguments(value: unknown): unknown {
  if (typeof value === 'string') return value
    .replace(/([a-z][a-z0-9+.-]*:\/\/)[^\s/@]+@/giu, '$1<credentials>@')
    .replace(/((?:password|passwd|api[_-]?key|access[_-]?token|secret)\s*[=:]\s*)(?:"[^"]*"|'[^']*'|[^\s;]+)/giu, '$1<redacted>')
    .replace(/(--password(?:=|\s+))(?:"[^"]*"|'[^']*'|[^\s;]+)/giu, '$1<redacted>')
  if (Array.isArray(value)) return value.map(redactReviewArguments)
  if (value !== null && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, entry]) => [key,
    /password|passwd|secret|token|api.?key|private.?key/iu.test(key) ? '<redacted>' : redactReviewArguments(entry)]))
  return value
}

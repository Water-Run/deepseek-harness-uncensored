/** Reconstructable independent target-review requests, outside the conversation's model-visible surface. */
import type { ToolCallId } from '@deepseek-ai/dsh-llm'
import type { ActionAssessment, ProtectionReviewId } from './types.ts'

declare module '@deepseek-ai/dsh-session/types' {
  interface SessionEventMap {
    /** Exact independent reviewer input, recorded before contacting its model; does not alter the main conversation context. */
    'target-protection/review-request': {
      version: 1
      reviewId: ProtectionReviewId
      callId: ToolCallId
      provider: string
      model: string
      system: string
      input: string
      maxTokens: number
    }
    /** Independent reviewer output or failure for one admitted review request. */
    'target-protection/review-result': {
      version: 1
      reviewId: ProtectionReviewId
      callId: ToolCallId
      outcome: { status: 'assessed'; assessment: ActionAssessment; text: string } | { status: 'failed'; error: string }
    }
  }
}

export {}

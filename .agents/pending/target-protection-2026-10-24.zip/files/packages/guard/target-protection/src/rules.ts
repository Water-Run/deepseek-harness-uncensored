/** Canonical address matching and deterministic production/test precedence. */
import { domainToASCII } from 'node:url'
import { isIP } from 'node:net'
import { isAbsolute, relative, resolve } from 'node:path'
import { RE2JS } from 're2js'
import ipaddr from 'ipaddr.js'
import { z } from 'zod'
import { brandString } from '@deepseek-ai/dsh-brand'
import type { ActionAssessment, ActionTarget, ProtectedTarget, ProtectedTargetId, ProtectionDecision, ProtectionPreferences } from './types.ts'

const targetSchema = z.object({
  id: z.string().uuid().transform(value => brandString<ProtectedTargetId>(value)),
  name: z.string().trim().min(1).max(100), kind: z.enum(['server', 'database', 'domain']),
  environment: z.enum(['production', 'test']), protection: z.enum(['full', 'audit']), enabled: z.boolean(),
  match: z.enum(['host', 'domain', 'regex', 'cidr', 'path']), address: z.string().trim().min(1).max(512),
  port: z.number().int().min(1).max(65535).optional(), database: z.string().trim().min(1).max(128).optional(),
}).strict().transform(({ port, database, ...rule }) => ({ ...rule,
  ...(port === undefined ? {} : { port }), ...(database === undefined ? {} : { database }) }))
/** Validate complete remote and durable settings before compiling any matchers. */
export const preferencesSchema = z.object({ mainlandDomains: z.boolean(), targets: z.array(targetSchema).max(200) }).strict()
/** Validate independent model assessments before they may influence admission. */
export const assessmentSchema = z.object({
  action: z.enum(['read', 'change', 'execute', 'unknown']), localOnly: z.boolean(), uncertain: z.boolean(),
  targets: z.array(z.object({ host: z.string().min(1).max(512).optional(), port: z.number().int().min(1).max(65535).optional(),
    database: z.string().max(128).optional(), path: z.string().max(4096).optional() }).strict()
    .refine(target => target.host !== undefined || target.path !== undefined, 'An assessment target needs an address.')
    .transform(({ host, port, database, path }) => ({ ...(host === undefined ? {} : { host }), ...(port === undefined ? {} : { port }),
      ...(database === undefined ? {} : { database }), ...(path === undefined ? {} : { path }) }))).max(200),
}).strict()

/**
 * Normalize a hostname, IP literal or connection URL, without retaining credentials.
 * @param input - Address supplied by a user, tool or reviewer.
 * @returns Canonical hostname; invalid addresses fail instead of matching nothing.
 */
export function canonicalHost(input: string): string {
  const value = input.trim()
  let hostname: string
  try { hostname = new URL(value.includes('://') ? value : `http://${value}`).hostname }
  catch { throw new Error('Enter a valid hostname, IP address or URL.') }
  hostname = hostname.replace(/^\[|\]$/gu, '').replace(/\.+$/u, '').toLowerCase()
  if (isIP(hostname)) return ipaddr.process(hostname).toString()
  const ascii = domainToASCII(hostname)
  if (!ascii || ascii.length > 253 || !/^[a-z0-9_-]+(?:\.[a-z0-9_-]+)*$/u.test(ascii)) throw new Error('Invalid hostname.')
  return ascii
}

/**
 * Extract credential-free coordinates from one connection URL.
 * @param value - Absolute URL, including database connection schemes.
 * @returns Parsed target, or undefined when the input is not a URL.
 */
export function targetFromUrl(value: string): ActionTarget | undefined {
  try {
    const url = new URL(value)
    if (!url.hostname) return undefined
    const databaseProtocol = /^(?:postgres(?:ql)?|mysql|mariadb|mongodb(?:\+srv)?|redis|mssql):$/u.test(url.protocol)
    const database = databaseProtocol ? decodeURIComponent(url.pathname.replace(/^\//u, '').split('/')[0] ?? '') : undefined
    const defaults: Readonly<Record<string, number>> = { 'http:': 80, 'https:': 443, 'postgres:': 5432, 'postgresql:': 5432,
      'mysql:': 3306, 'mariadb:': 3306, 'mongodb:': 27017, 'redis:': 6379, 'mssql:': 1433 }
    const port = url.port ? Number(url.port) : defaults[url.protocol]
    return { host: canonicalHost(url.hostname), ...(port === undefined ? {} : { port }),
      ...(database ? { database } : {}) }
  } catch { return undefined }
}

/**
 * Validate and canonicalize user rules before persistence; connection credentials are never accepted.
 * @param input - Complete preferences from a wire or durable boundary.
 * @returns Validated, credential-free preferences.
 */
export function resolvePreferences(input: unknown): ProtectionPreferences {
  const preferences = preferencesSchema.parse(input)
  for (const rule of preferences.targets) {
    if (rule.database !== undefined && rule.kind !== 'database') throw new Error('A database name requires a database target.')
    if (rule.match !== 'host' && rule.match !== 'domain') continue
    if (rule.address.includes('://')) {
      const url = new URL(rule.address)
      if (url.username || url.password) throw new Error('Store only the target address; remove connection credentials.')
      const target = targetFromUrl(rule.address)
      if (target === undefined) throw new Error('Invalid target URL.')
      if (rule.port === undefined && target.port !== undefined) rule.port = target.port
      if (rule.kind === 'database' && rule.database === undefined && target.database !== undefined) rule.database = target.database
    }
    rule.address = canonicalHost(rule.address)
  }
  return preferences
}

interface CompiledTarget { rule: ProtectedTarget; hostMatches?: (host: string) => boolean; path?: string }

function compile(rule: ProtectedTarget): CompiledTarget {
  switch (rule.match) {
    case 'host': { const expected = canonicalHost(rule.address); return { rule, hostMatches: host => host === expected } }
    case 'domain': {
      const expected = canonicalHost(rule.address)
      if (isIP(expected)) throw new Error('Use exact host or CIDR matching for IP addresses.')
      return { rule, hostMatches: host => host === expected || host.endsWith(`.${expected}`) }
    }
    case 'regex': {
      const expression = RE2JS.compile(rule.address, RE2JS.CASE_INSENSITIVE)
      return { rule, hostMatches: host => expression.test(host) }
    }
    case 'cidr': {
      const network = ipaddr.parseCIDR(rule.address)
      return { rule, hostMatches: (host) => {
        if (!isIP(host)) return false
        const ip = ipaddr.process(host)
        return ip.kind() === network[0].kind() && ip.match(network)
      } }
    }
    case 'path': {
      if (!isAbsolute(rule.address)) throw new Error('Local database paths must be absolute.')
      return { rule, path: resolve(rule.address) }
    }
  }
}

function matches(compiled: CompiledTarget, target: ActionTarget): boolean {
  const { rule } = compiled
  if (rule.environment === 'test' && ((rule.database !== undefined && rule.database !== target.database)
    || (rule.port !== undefined && rule.port !== target.port))) return false
  if (rule.database !== undefined && target.database !== undefined && rule.database !== target.database) return false
  if (rule.port !== undefined && target.port !== undefined && rule.port !== target.port) return false
  if (compiled.path !== undefined) {
    if (target.path === undefined || !isAbsolute(target.path)) return false
    const suffix = relative(compiled.path, resolve(target.path))
    return suffix === '' || (!isAbsolute(suffix) && suffix !== '..' && !suffix.startsWith('../') && !suffix.startsWith('..\\'))
  }
  return target.host !== undefined && compiled.hostMatches?.(canonicalHost(target.host)) === true
}

function mainlandDomain(host: string): boolean {
  const normalized = canonicalHost(host)
  return ['cn', 'xn--fiqs8s', 'xn--fiqz9s'].some(tld => normalized === tld || normalized.endsWith(`.${tld}`))
}

/** Validated rules, compiled once per durable configuration revision. */
export class ProtectionRules {
  private readonly compiled: CompiledTarget[]
  /**
   * Reject invalid regexes, CIDRs, paths and duplicate identities before a configuration can be saved.
   * @param preferences - Validated user-owned target rules.
   */
  constructor(readonly preferences: ProtectionPreferences) {
    const ids = new Set(preferences.targets.map(rule => rule.id))
    if (ids.size !== preferences.targets.length) throw new Error('Target identities must be unique.')
    this.compiled = preferences.targets.map(compile).filter(target => target.rule.enabled)
  }

  /**
   * Check an assessment; production rules outrank test exceptions, and test exceptions outrank automatic domain protection.
   * @param assessment - Exact operation effects and affected addresses.
   * @param mainland - Whether the current mode applies the mainland-domain preference.
   * @returns Permission or a stable explanatory denial.
   */
  decide(assessment: ActionAssessment, mainland: boolean): ProtectionDecision {
    const activeMainland = mainland && this.preferences.mainlandDomains
    const production = this.compiled.filter(target => target.rule.environment === 'production')
    if (!activeMainland && production.length === 0) return { allowed: true, targetIds: [] }
    if (assessment.uncertain || (!assessment.localOnly && assessment.targets.length === 0)) {
      return { allowed: false, reason: 'The action targets or effects could not be established under the active protection rules.', targetIds: [] }
    }
    const targetIds: ProtectedTargetId[] = []
    for (const target of assessment.targets) {
      const matched = this.compiled.filter(rule => matches(rule, target))
      const protectedRules = matched.filter(candidate => candidate.rule.environment === 'production')
      for (const { rule } of protectedRules) {
        targetIds.push(rule.id)
        if (rule.protection === 'full' || assessment.action !== 'read') {
          return { allowed: false, targetIds, reason: `Target protection blocked access to "${rule.name}" (${rule.protection === 'full' ? 'fully protected' : 'read-only audit'}).` }
        }
      }
      if (protectedRules.length > 0) continue
      const test = matched.find(candidate => candidate.rule.environment === 'test')
      if (test !== undefined) { targetIds.push(test.rule.id); continue }
      if (activeMainland && target.host !== undefined && mainlandDomain(target.host) && assessment.action !== 'read') {
        return { allowed: false, targetIds, reason: 'Mainland-domain protection permits read-only inspection, but blocks execution or changes against this domain.' }
      }
    }
    return { allowed: true, targetIds }
  }

  /**
   * Whether an execution needs target assessment under the current settings.
   * @param mainland - Whether this mode uses automatic mainland-domain protection.
   * @returns True while any applicable protection is active.
   */
  active(mainland: boolean): boolean {
    return (mainland && this.preferences.mainlandDomains) || this.compiled.some(target => target.rule.environment === 'production')
  }
}

/** Built-in production/domain protection with independent effect review and final execution guards. */
import { Service, type Context } from '@deepseek-ai/cordis'
import schema from '@deepseek-ai/schemastery'
import { Remote, RemoteError, TypertRemoteService, principalOf } from '@deepseek-ai/dsh-typert-protocol'
import { RUN_CODE_NAME, type ToolExecution, type PreToolDecision } from '@deepseek-ai/dsh-tools'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type {} from '@deepseek-ai/dsh-agent-preset-registry'
import type {} from '@deepseek-ai/dsh-session-projection'
import type {} from '@deepseek-ai/dsh-working-directory'
import type {} from '@deepseek-ai/dsh-fs'
import type {} from './session.ts'
import { ProtectionConflict, ProtectionStore } from './store.ts'
import { ProtectionRules } from './rules.ts'
import { fileTargets, literalTargets, structuredAssessment } from './assessment.ts'
import { reviewAction, type ReviewPolicy } from './reviewer.ts'
import type { ActionAssessment, ProtectionPreferences, ProtectionSnapshot } from './types.ts'

export type * from './types.ts'

/** Storage and review bounds; user target rules are saved in the independent registry. */
export interface Config {
  path: string
  sqliteBusyMs: number
  mainlandModes: string[]
  reviewTimeoutMs: number
  reviewMaxTokens: number
  reviewInputBytes: number
  reviewOutputBytes: number
}
/** Validated deployment configuration. */
export const Config = schema.object({ path: schema.string().required(),
  sqliteBusyMs: schema.natural().min(1).max(30000).default(5000),
  mainlandModes: schema.array(schema.string()).default(['security', 'reverse']),
  reviewTimeoutMs: schema.natural().min(1000).max(300000).default(60000),
  reviewMaxTokens: schema.natural().min(256).max(16384).default(2048),
  reviewInputBytes: schema.natural().min(1024).max(1048576).default(131072),
  reviewOutputBytes: schema.natural().min(1024).max(1048576).default(65536),
})
export const name = 'target-protection'
export const inject: string[] = []

declare module '@deepseek-ai/cordis' { interface Context { targetProtection: TargetProtectionRemote } }

type Prepared = { assessment: ActionAssessment } | { failed: string }

/** Owns admission, in-flight reviews and the database through shutdown. */
class ProtectionRuntime {
  private store: ProtectionStore | undefined
  private readonly ready: Promise<ProtectionStore>
  private compiled: { revision: number; rules: ProtectionRules } | undefined
  private readonly prepared = new WeakMap<ToolExecution, Prepared>()
  private readonly active = new Set<Promise<unknown>>()
  private readonly lifecycle = new AbortController()
  private accepting = true
  private readonly review: ReviewPolicy

  constructor(private readonly ctx: Context, private readonly config: Config) {
    this.review = { timeoutMs: config.reviewTimeoutMs, maxTokens: config.reviewMaxTokens,
      inputBytes: config.reviewInputBytes, outputBytes: config.reviewOutputBytes }
    this.ready = ProtectionStore.open(config.path, config.sqliteBusyMs).then((store) => { this.store = store; return store })
    void this.ready.catch((error: unknown) => { ctx.logger.error('Target protection is unavailable; protected execution remains blocked.', error) })
  }

  private track<T>(task: Promise<T>): Promise<T> {
    this.active.add(task)
    const finish = (): void => { this.active.delete(task) }
    void task.then(finish, finish)
    return task
  }

  async withStore<T>(operation: (store: ProtectionStore) => T): Promise<T> {
    if (!this.accepting) throw new Error('Target protection is closing.')
    return this.track(this.ready.then(operation))
  }

  private rules(): ProtectionRules {
    if (this.store === undefined) throw new Error('Target protection has not initialized; execution is blocked.')
    const snapshot = this.store.snapshot()
    if (this.compiled?.revision !== snapshot.revision) {
      this.compiled = { revision: snapshot.revision, rules: new ProtectionRules(snapshot.preferences) }
    }
    return this.compiled.rules
  }

  private mainland(ctx: Context, agent: Agent | undefined): boolean {
    if (agent === undefined) return false
    const current = ctx.get('agentPresets')?.composedPreset(agent.ctx) ?? agent.session.header.agentPreset
    if (current !== undefined && this.config.mainlandModes.includes(current)) return true
    let header = agent.session.header
    const visited = new Set<string>()
    while (header.parentSession !== undefined && (header.origin === 'subagent'
      || header.id.startsWith('session-side-') || header.id.startsWith('session-btw-'))) {
      if (visited.has(header.id)) return true
      visited.add(header.id)
      const parent = ctx.sessions.get(header.parentSession)
      if (parent === undefined) return true
      const mode = ctx.get('sessionProjections')?.stateOf(parent, 'agentPreset') ?? parent.header.agentPreset
      if (mode != null && this.config.mainlandModes.includes(mode)) return true
      header = parent.header
    }
    return false
  }

  private transport(exec: ToolExecution): boolean { return exec.parent === undefined && exec.name === RUN_CODE_NAME }

  async before(ctx: Context, exec: ToolExecution, next: () => Promise<PreToolDecision>, ownerSignal: AbortSignal): Promise<PreToolDecision> {
    if (!this.accepting) return { kind: 'cancel' }
    if (this.transport(exec)) return next()
    await this.track(this.assess(ctx, exec, ownerSignal))
    if (this.lifecycle.signal.aborted || ownerSignal.aborted || exec.signal.aborted) return { kind: 'cancel' }
    const reason = this.guard(ctx, exec)
    return reason === undefined ? next() : { kind: 'deny', reason, info: { name: 'TargetProtectionDeniedError', code: 'TARGET_PROTECTION_BLOCKED' } }
  }

  private async assess(ctx: Context, exec: ToolExecution, ownerSignal: AbortSignal): Promise<void> {
    try {
      await this.ready
      const rules = this.rules()
      const mainland = this.mainland(ctx, exec.agent)
      if (!rules.active(mainland)) return
      const signal = AbortSignal.any([exec.signal, this.lifecycle.signal, ownerSignal])
      signal.throwIfAborted()
      const literal = literalTargets(exec.arguments)
      const early = rules.decide({ action: 'read', targets: literal, localOnly: literal.length === 0, uncertain: false }, mainland)
      if (!early.allowed) { this.prepared.set(exec, { failed: early.reason ?? 'Target protection blocked this action.' }); return }
      const cwd = exec.agent === undefined ? process.cwd() : await ctx.workingDirectory.ensure(exec.agent, signal)
      const fs = exec.agent === undefined ? ctx.get('fs') : ctx.get('agentPresets')?.serviceFor(exec.agent, 'fs') ?? ctx.get('fs')
      const executionHost = fs?.executionHost
      let assessment = await structuredAssessment(exec, cwd, executionHost)
      if (assessment === undefined) assessment = await reviewAction(ctx, exec, cwd, this.review, signal)
      const targets = []
      for (const target of assessment.targets) {
        if (target.path === undefined || target.host !== undefined || executionHost !== undefined) targets.push(target)
        else for (const file of await fileTargets(target.path, cwd)) targets.push({ ...target, ...file })
      }
      signal.throwIfAborted()
      this.prepared.set(exec, { assessment: { ...assessment, targets } })
    } catch (error) {
      this.prepared.set(exec, { failed: `Target protection could not complete its check; no action was executed. ${error instanceof Error ? error.message : ''}` })
    }
  }

  guard(ctx: Context, exec: ToolExecution): string | undefined {
    if (this.transport(exec)) return undefined
    if (!this.accepting) return 'Target protection is closing; execution is blocked.'
    try {
      const rules = this.rules(), mainland = this.mainland(ctx, exec.agent)
      if (!rules.active(mainland)) return undefined
      const checked = this.prepared.get(exec)
      if (checked === undefined) return 'Target protection requires a completed assessment before execution.'
      if ('failed' in checked) return checked.failed
      const decision = rules.decide(checked.assessment, mainland)
      return decision.allowed ? undefined : decision.reason ?? 'Target protection blocked this action.'
    } catch (error) { return `Target protection is unavailable; execution is blocked. ${error instanceof Error ? error.message : ''}` }
  }

  async authorize(assessment: ActionAssessment, signal?: AbortSignal): Promise<void> {
    signal?.throwIfAborted()
    await this.withStore(() => {
      signal?.throwIfAborted()
      const decision = this.rules().decide(assessment, false)
      if (!decision.allowed) throw new Error(decision.reason ?? 'Target protection blocked this operation.')
    })
  }

  forget(exec: ToolExecution): void { this.prepared.delete(exec) }
  async close(): Promise<void> {
    this.accepting = false
    this.lifecycle.abort(new Error('Target protection is closing.'))
    await Promise.allSettled([...this.active])
    const store = await this.ready.catch(() => undefined)
    store?.close()
  }
}

/** Authenticated persistent target settings; changes affect subsequent admission checks immediately. */
export class TargetProtectionRemote extends TypertRemoteService {
  /** @param ctx - Remote owner. @param runtime - Guard and storage lifetime owner. */
  constructor(ctx: Context, private readonly runtime: ProtectionRuntime) { super(ctx, 'targetProtection') }

  protected async [Service.init](): Promise<void> { await this.runtime.withStore(() => undefined) }

  /**
   * Enforce explicit target rules at a trusted transport operation before it sends anything.
   * @param assessment - Provider-owned destination and effects, never a model-supplied permission grant.
   * @param signal - Operation cancellation.
   * @returns Completion only when the operation is admitted.
   */
  authorize(assessment: ActionAssessment, signal?: AbortSignal): Promise<void> { return this.runtime.authorize(assessment, signal) }

  /**
   * Read the latest rules shared by conversations and local processes.
   * @returns Current durable configuration.
   */
  @Remote
  get(): Promise<ProtectionSnapshot> {
    if (principalOf(this.ctx.invocation) !== undefined) throw new RemoteError('target-protection/owner-required', 'Only the application owner may read protection rules.', {})
    return this.runtime.withStore(store => store.snapshot())
  }

  /**
   * Save owner-edited rules with revision conflict detection.
   * @param preferences - Complete target preferences.
   * @param expectedRevision - Revision shown by the editor.
   * @returns Committed configuration.
   */
  @Remote
  async configure(preferences: ProtectionPreferences, expectedRevision: number): Promise<ProtectionSnapshot> {
    if (principalOf(this.ctx.invocation) !== undefined) throw new RemoteError('target-protection/owner-required', 'Only the application owner may edit protection rules.', {})
    try { return await this.runtime.withStore(store => store.configure(preferences, expectedRevision)) }
    catch (error) {
      if (error instanceof ProtectionConflict) throw new RemoteError('target-protection/conflict', error.message, { revision: error.revision })
      throw new RemoteError('target-protection/invalid', 'Protection settings were not saved.', { reason: error instanceof Error ? error.message : 'Invalid rules.' })
    }
  }
}

/**
 * Install the asynchronous review and monotonic guard before exposing settings.
 * @param ctx - Application tools and model services.
 * @param config - Validated deployment bounds and registry path.
 */
export function apply(ctx: Context, config: Config): void {
  const runtime = new ProtectionRuntime(ctx, config)
  const service = ctx.plugin(TargetProtectionRemote, runtime)
  ctx.inject(['tools', 'llm', 'sessions', 'workingDirectory'], (scope) => {
    const lifetime = new AbortController()
    const active = new Set<Promise<PreToolDecision>>()
    const stopBefore = scope.on('tools/pre-execute', (exec, next) => {
      const task = runtime.before(scope, exec, next, lifetime.signal)
      active.add(task)
      const finish = (): void => { active.delete(task) }
      void task.then(finish, finish)
      return task
    }, { prepend: true })
    const stopGuard = scope.tools.guard(exec => lifetime.signal.aborted ? 'Target protection is reloading.' : runtime.guard(scope, exec))
    const stopResult = scope.on('tools/result', (exec) => { runtime.forget(exec) })
    scope.effect(() => async () => {
      stopBefore(); lifetime.abort()
      await Promise.allSettled([...active])
      stopGuard(); stopResult()
    }, 'target-protection: tool consumers')
  })
  ctx.effect(() => async () => {
    await runtime.close()
    await service.dispose()
  }, 'target-protection: admission and registry')
}

/** Persistent target rules and execution assessments shared by Host and Client. */
import type { Branded } from '@deepseek-ai/dsh-brand'

/** Stable identity of a user-owned target rule. */
export type ProtectedTargetId = Branded<'ProtectedTargetId'>
/** Stable identity of one independent pending-action review. */
export type ProtectionReviewId = Branded<'ProtectionReviewId'>
/** Address matching method; regex is evaluated against the normalized hostname. */
export type TargetMatchKind = 'host' | 'domain' | 'regex' | 'cidr' | 'path'
/** A production resource or explicit test exception, shared across conversations. */
export interface ProtectedTarget {
  id: ProtectedTargetId
  name: string
  kind: 'server' | 'database' | 'domain'
  environment: 'production' | 'test'
  protection: 'full' | 'audit'
  enabled: boolean
  match: TargetMatchKind
  address: string
  port?: number
  database?: string
}
/** User preferences; mainland-domain protection defaults on. */
export interface ProtectionPreferences {
  mainlandDomains: boolean
  targets: ProtectedTarget[]
}
/** A durable configuration revision used to fence decisions made before a settings change. */
export interface ProtectionSnapshot { revision: number; preferences: ProtectionPreferences }
/** Credential-free address an operation may affect. */
export interface ActionTarget { host?: string; port?: number; database?: string; path?: string }
/** Classified effects, not a permission grant. Rule matching makes the final decision. */
export interface ActionAssessment {
  action: 'read' | 'change' | 'execute' | 'unknown'
  targets: ActionTarget[]
  localOnly: boolean
  uncertain: boolean
}
/** Result returned by the deterministic rule evaluator. */
export interface ProtectionDecision { allowed: boolean; reason?: string; targetIds: ProtectedTargetId[] }

declare module '@deepseek-ai/dsh-typert-protocol' {
  interface RemoteErrorDetailsMap {
    /** A configuration update used an older revision than the durable current value. */
    'target-protection/conflict': { readonly revision: number }
    /** Only the application owner may edit production/test target rules. */
    'target-protection/owner-required': Record<string, never>
    /** A target rule or its regular expression is invalid. */
    'target-protection/invalid': { readonly reason: string }
  }
}

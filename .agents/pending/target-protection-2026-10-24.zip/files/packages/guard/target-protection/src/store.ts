/** Revisioned target rules shared by local processes without persisting credentials. */
import { DatabaseSync } from 'node:sqlite'
import { mkdir, open } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { z } from 'zod'
import { ProtectionRules, resolvePreferences } from './rules.ts'
import type { ProtectionPreferences, ProtectionSnapshot } from './types.ts'

/** Monotonic format version for the independent target registry. */
export const SCHEMA_VERSION = 1
const rowSchema = z.object({ revision: z.number().int().positive(), value: z.string() })
const DEFAULTS: ProtectionPreferences = { mainlandDomains: true, targets: [] }

/** A caller attempted to overwrite a newer settings revision. */
export class ProtectionConflict extends Error {
  /** @param revision - Current durable revision that the caller must reload. */
  constructor(readonly revision: number) { super('Target rules changed in another window. Reload before saving.') }
}

/** Owns the target catalog; reads use committed state from every process sharing its path. */
export class ProtectionStore {
  private constructor(private readonly db: DatabaseSync) {}

  /**
   * Open and validate the independent target catalog without resetting malformed state.
   * @param path - SQLite filename, or :memory: in an isolated test.
   * @param busyTimeoutMs - Maximum wait for another process's database lock.
   * @returns An owned store; close it after consumers finish.
   */
  static async open(path: string, busyTimeoutMs: number): Promise<ProtectionStore> {
    const file = path === ':memory:' ? path : resolve(path)
    if (file !== ':memory:') {
      await mkdir(dirname(file), { recursive: true, mode: 0o700 })
      try { const handle = await open(file, 'wx', 0o600); await handle.close() }
      catch (error) { if ((error as NodeJS.ErrnoException).code !== 'EEXIST') throw error }
    }
    const db = new DatabaseSync(file, { timeout: busyTimeoutMs })
    try {
      db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL')
      const version = z.object({ user_version: z.number().int() }).parse(db.prepare('PRAGMA user_version').get()).user_version
      if (version !== 0 && version !== SCHEMA_VERSION) throw new Error(`Unsupported target registry version: ${version}`)
      const store = new ProtectionStore(db)
      store.transaction(() => {
        db.exec('CREATE TABLE IF NOT EXISTS preferences (id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL, value TEXT NOT NULL) STRICT')
        db.prepare('INSERT OR IGNORE INTO preferences VALUES (1, 1, ?)').run(JSON.stringify(DEFAULTS))
        new ProtectionRules(store.snapshot().preferences)
        db.exec(`PRAGMA user_version=${SCHEMA_VERSION}`)
      })
      return store
    } catch (error) { db.close(); throw error }
  }

  private transaction<T>(run: () => T): T {
    this.db.exec('BEGIN IMMEDIATE')
    try { const value = run(); this.db.exec('COMMIT'); return value }
    catch (error) { this.db.exec('ROLLBACK'); throw error }
  }

  /**
   * Read current committed preferences with fresh ownership of every returned object.
   * @returns The durable settings revision.
   */
  snapshot(): ProtectionSnapshot {
    const row = rowSchema.parse(this.db.prepare('SELECT revision, value FROM preferences WHERE id=1').get())
    const preferences = resolvePreferences(JSON.parse(row.value))
    return { revision: row.revision, preferences }
  }

  /**
   * Validate and atomically replace preferences if the caller's revision is current.
   * @param preferences - Complete user-owned rules.
   * @param expectedRevision - Revision displayed by the editor.
   * @returns The new committed snapshot.
   */
  configure(preferences: ProtectionPreferences, expectedRevision: number): ProtectionSnapshot {
    const value = resolvePreferences(preferences)
    new ProtectionRules(value)
    return this.transaction(() => {
      const current = this.snapshot()
      if (current.revision !== expectedRevision) throw new ProtectionConflict(current.revision)
      this.db.prepare('UPDATE preferences SET revision=revision+1, value=? WHERE id=1').run(JSON.stringify(value))
      return this.snapshot()
    })
  }

  /** Release the database after guards and Remote operations are drained. */
  close(): void { this.db.close() }
}
